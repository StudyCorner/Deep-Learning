# Convolution-Neural-Network-using-Python-

we are going to see about Convolution Neural Network working using Keras and Tensorflow . 
We are going to build a CNN Model and training a multiple type of classification. In this cnn model i am using a layer 
like Dropout, Convolution 2D , Max Pooling 2D , Dense to build my model. 

Dataset - The CIFAR-10 dataset (Automatically download from Keras when you are Run the code) 
Description - https://www.cs.toronto.edu/~kriz/cifar.html
